const axios= require('axios')
const url='http://api.openweathermap.org/data/2.5/weather?q='
const key='20357abb535e856115b64311202ebe9d'  

async function getData(city){
    const resPost = await axios.get(`${url}${city}&appid=${key}`)
    const data = resPost.data
    const main = data.main
    const name =data.name
    const temp= main.temp
    const max= main.temp_max
    const min= main.temp_min
    const lista=await {'name':name, 'temp':temp, 'max':max, 'min':min}
    return await lista   
}

async function update(answer,name,model){
    if (answer == "Add City"){
        const cantidad = await model[0].cant + 1
        console.log(await cantidad)
        model[0].cant = await cantidad
        const list = await getData(name)
        console.log(await list)
        model.push(await list)
    }

    else if(answer == "Delete City"){
        update_delete(model, name)
    }
    console.log(await model)
    return await model
    


}

function update_delete(model,name2){
    const names = model
    for(var i = 0; i<model[0].cant;i++){
        if(names[i].name == name2){
            break

        }

    }
    let pos = model.splice(i,1)
    
    
    var cantidad = model[0].cant - 1
    model[0].cant = cantidad


}

module.exports = {
    update,
    update_delete
}