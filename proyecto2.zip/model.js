const axios= require('axios')
const url='http://api.openweathermap.org/data/2.5/weather?q='
const key='20357abb535e856115b64311202ebe9d'
initModel=[{cant:1}]
async function getData(initModel){
    const resPost = await axios.get(`${url}santiago&appid=${key}`)
    const data = resPost.data
    const main = data.main
    const name =data.name
    const temp= main.temp
    const max= main.temp_max
    const min= main.temp_min
    const lista=await {'name':name, 'temp':temp, 'max':max, 'min':min}
    await initModel.push(lista)
    return await initModel   
}

initModel = getData(initModel)

module.exports = {
    initModel
}